package MoteurGraphique;

public class MoteurGraphique {
    
    public MoteurGraphique(){
        
    }

    public void start() {
    }


}
