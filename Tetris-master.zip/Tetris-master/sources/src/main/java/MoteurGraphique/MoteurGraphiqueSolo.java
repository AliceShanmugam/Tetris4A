package MoteurGraphique;

import MoteurDeJeu.Pieces.Piece;
import MoteurDeJeu.Plateau;

public class MoteurGraphiqueSolo extends MoteurGraphique{

    // Met à jour l'affichage du jeu
    public void update(Plateau plateau, Piece nextPiece, int score) {

    }
}
