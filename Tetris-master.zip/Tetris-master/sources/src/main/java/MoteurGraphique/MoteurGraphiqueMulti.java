package MoteurGraphique;

import MoteurDeJeu.Pieces.Piece;
import MoteurDeJeu.Plateau;

public class MoteurGraphiqueMulti extends MoteurGraphique{

    public void update(Plateau plateau, Piece nextPiece, int score, int score2, Object malus) {

    }
}
