package MoteurDeJeu;

import MoteurGraphique.MoteurGraphiqueSolo;

public class JeuSolo extends Jeu {

    public JeuSolo(MoteurGraphiqueSolo moteurGraphique) {
    }
}
