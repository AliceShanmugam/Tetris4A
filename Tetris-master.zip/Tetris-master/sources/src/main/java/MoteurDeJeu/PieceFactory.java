package MoteurDeJeu;

public class PieceFactory {
}
