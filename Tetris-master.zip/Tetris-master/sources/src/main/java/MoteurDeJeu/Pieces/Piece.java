package MoteurDeJeu.Pieces;

public class Piece {
}
