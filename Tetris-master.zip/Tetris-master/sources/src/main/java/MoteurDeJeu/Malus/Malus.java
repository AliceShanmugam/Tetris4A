package MoteurDeJeu.Malus;

public class Malus {
}
