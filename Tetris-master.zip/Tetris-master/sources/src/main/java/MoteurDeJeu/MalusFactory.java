package MoteurDeJeu;

public class MalusFactory {
}
