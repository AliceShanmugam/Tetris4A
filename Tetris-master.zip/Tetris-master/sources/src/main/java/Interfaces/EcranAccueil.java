package Interfaces;

public class EcranAccueil {

    // Lance l'interface d'accueil et retourne une reponse de type AccueilResult
    public AccueilResult start() {



        return new AccueilResult(true,"");
    }


}
