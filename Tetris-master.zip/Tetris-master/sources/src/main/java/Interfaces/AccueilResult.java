package Interfaces;

public class AccueilResult {

    public boolean solo;
    public String ip;

    public AccueilResult(boolean solo, String ip){
        this.solo = solo;
        this.ip = ip;
    }
}
