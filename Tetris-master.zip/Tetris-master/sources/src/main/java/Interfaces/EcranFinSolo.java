package Interfaces;

public class EcranFinSolo {

    // Score final
    private int score;

    public EcranFinSolo(int score) {

    }

    public EcranFinSolo(int score, int score2, boolean victoire) {

    }

    // Affiche l'ecran
    public void show() {

    }
}
